# Índice de Skills

O Google AI Studio Build pode não carregar automaticamente pastas `.agents/skills`. Por isso, o `AGENTS.md` instrui explicitamente o agente a abrir os arquivos relevantes. Se o ambiente não respeitar essa instrução, cole no contexto da tarefa o conteúdo de `AGENTS.md` e das Skills necessárias.

## Skills do projeto
| Skill | Quando consultar |
|---|---|
| `project-preservation` | Toda tarefa em projeto existente |
| `product-design-system` | UI, UX, cores, tipografia, layout e identidade |
| `interface-quality` | Revisão de telas, fluxos, acessibilidade e estados |
| `motion-design` | Animações, transições e feedback visual |
| `engineering-quality` | Arquitetura, APIs, estado, dados e manutenção |
| `react-performance` | Somente se o stack usar React |
| `security-review` | Auth, permissões, dados pessoais, webhooks, segredos |
| `live-session-integrity` | TikTok LIVE, sorteios, eventos, participantes e moedas |
| `qa-regression` | Testes, auditoria, validação e releases |

## Regra de seleção
Leia a menor combinação de Skills suficiente para a tarefa. Para mudanças críticas, combine `project-preservation`, `engineering-quality`, `security-review`, `live-session-integrity` e `qa-regression`.
